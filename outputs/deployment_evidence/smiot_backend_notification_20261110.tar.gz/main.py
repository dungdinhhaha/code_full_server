from service.observability import initialize_tracing

initialize_tracing()

from nicegui import ui, app
from pathlib import Path
import asyncio
import json
import os
import secrets
import subprocess
import sys
import threading

# Serve thư mục static (chứa ảnh thiết bị)
app.add_static_files('/static', Path(__file__).parent / 'static')

# ── Khởi tạo Database Auth (tạo bảng users, permissions nếu chưa có) ──
from service.auth import init_db
init_db()

# Import các trang để router NiceGUI nhận diện
import pages.login
import pages.home
import pages.project
import pages.inverter
import pages.plc
import pages.devices
import pages.permission
import pages.schedule
import pages.chart
import pages.data_table
import pages.traceability
import pages.mongodb_lab
import pages.public_lot

# Trang incident dang do agent khac tao: thieu module thi chi canh bao, khong chan app.
try:
    import pages.incident  # noqa: F401
except ImportError as exc:
    from service.logger import get_logger as _get_early_logger
    _get_early_logger("SYSTEM").warning("Bo qua pages.incident (chua san sang): %s", exc)

# Server startup configs
from service.mqtt import start_mqtt, publish_mqtt
start_mqtt()

from service.scheduler import start_background_scheduler
start_background_scheduler()

# Demo data is isolated by stable demo identifiers and contains no pump commands.
from service.demo_mode import start_demo_mode
start_demo_mode()

# Poll Mongo independently from MQTT so a silent telemetry stream stays observable.
from service.telemetry_health import start_telemetry_health_watchdog
start_telemetry_health_watchdog()

# Publish detector liveness independently from MQTT callbacks/findings.
from service.detector_heartbeat import start_detector_heartbeat
start_detector_heartbeat()

# ── 1. Thêm Middleware Access Log ──
from service.middleware import AccessLogMiddleware
app.add_middleware(AccessLogMiddleware)

# ── 2. Cấu hình Global Exception Handler (Bắt mọi lỗi gửi qua Telegram) ──
import sys
import threading
import traceback
from datetime import datetime, timezone
from fastapi.responses import JSONResponse
from fastapi.responses import Response
from fastapi import Request
from service.logger import get_logger

system_logger = get_logger("SYSTEM")
_recovery_clear_lock = threading.Lock()

def notify_error_to_telegram(exc_type, exc_value, exc_traceback, source="System"):
    """Ghi lỗi ra error.log và gửi cảnh báo lên Telegram qua MQTT."""
    tb_lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
    tb_text = "".join(tb_lines)
    
    # 1. Ghi ra logs/error.log (nhờ system_logger gọi error_handler)
    system_logger.error(f"[{source}] Unhandled Exception:\n{tb_text}")
    
    # 2. Rút gọn Traceback để gửi Telegram không bị quá dài
    short_tb = tb_text[-600:].replace('<', '&lt;').replace('>', '&gt;')
    msg = f"<b>🚨 FATAL CRASH ({source})</b>\n<code>{exc_type.__name__}: {exc_value}</code>\n<pre>{short_tb}</pre>"
    
    now_str = datetime.now().strftime("%H:%M:%S")
    publish_mqtt("farm/notify", {
        "message": msg,
        "category": "system",
        "severity": "error",
        "time": now_str
    })

def global_sys_excepthook(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    notify_error_to_telegram(exc_type, exc_value, exc_traceback, "MainThread")

def global_thread_excepthook(args):
    thread_name = args.thread.name if args.thread else "UnknownThread"
    notify_error_to_telegram(args.exc_type, args.exc_value, args.exc_traceback, thread_name)

# Gắn hook bắt lỗi cho luồng chính và luồng ngầm
sys.excepthook = global_sys_excepthook
threading.excepthook = global_thread_excepthook

# Bắt lỗi HTTP Requests của FastAPI
@app.exception_handler(Exception)
async def fastapi_exception_handler(request: Request, exc: Exception):
    notify_error_to_telegram(type(exc), exc, exc.__traceback__, f"Web (Path: {request.url.path})")
    return JSONResponse(
        status_code=500,
        content={"message": "Lỗi hệ thống nội bộ! Đã báo cáo cho Admin."}
    )
# Báo lỗi JS từ Client
@app.post('/api/js_error')
async def post_js_error(request: Request):
    try:
        data = await request.json()
        system_logger.error(f"[JS CLIENT ERROR] {data.get('message')} at {data.get('url')}:{data.get('line')}:{data.get('column')} - Stack: {data.get('stack')}")
        logs_dir = Path(__file__).parent / "logs"
        logs_dir.mkdir(exist_ok=True)
        with open(logs_dir / 'js_error.log', 'a', encoding='utf-8') as f:
            import json
            import time
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {json.dumps(data)}\n")
        return {"status": "ok"}
    except Exception as e:
        print(f"Error handling JS error log: {e}")
        return {"status": "error"}


# ── Health endpoint: không cần đăng nhập, không trả lỗi chi tiết, URI hay secret ──
from service.mongodb_store import collection, database

HEALTHZ_MONGO_TIMEOUT_SECONDS = 2.0


def build_healthz_payload(*, mongo_ok, mqtt_ok, newest_sample_at, now):
    """Dựng JSON /healthz từ kết quả kiểm tra. Hàm thuần: test được mà không cần Mongo."""
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    age = None
    if isinstance(newest_sample_at, datetime):
        stamp = newest_sample_at
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        age = round(max(0.0, (now - stamp.astimezone(timezone.utc)).total_seconds()), 1)
    return {
        "app": "ok",
        "mongo": "ok" if mongo_ok else "fail",
        "mqtt": "ok" if mqtt_ok else "fail",
        "newest_sample_age_seconds": age,
        "time_utc": now.astimezone(timezone.utc).isoformat(),
    }


async def _read_mongo_health(timeout=HEALTHZ_MONGO_TIMEOUT_SECONDS):
    """Ping Mongo và đọc mẫu mới nhất trong thread, có timeout ngắn. Trả (ok, newest_timestamp)."""
    def _probe():
        database().command("ping")
        row = collection("telemetry").find_one({}, {"timestamp": 1, "_id": 0}, sort=[("timestamp", -1)])
        return row.get("timestamp") if row else None
    try:
        newest = await asyncio.wait_for(asyncio.to_thread(_probe), timeout=timeout)
        return True, newest
    except Exception:
        return False, None


def _mqtt_connected():
    try:
        from service import mqtt as mqtt_service
        return bool(mqtt_service.mqtt_client and mqtt_service.mqtt_client.is_connected())
    except Exception:
        return False


@app.get('/healthz')
async def healthz():
    mongo_ok, newest = await _read_mongo_health()
    payload = build_healthz_payload(
        mongo_ok=mongo_ok,
        mqtt_ok=_mqtt_connected(),
        newest_sample_at=newest,
        now=datetime.now(timezone.utc),
    )
    return JSONResponse(payload, headers={"Cache-Control": "no-store"})


@app.post('/api/integrations/datadog/recovery-verification')
async def verify_datadog_ec2_recovery(request: Request):
    """Read SSM completion and re-check app dependencies; never starts a service.

    Payload contract: {"workflow_run_id": "<Datadog InstanceId>", "instance_id": "<EC2 instance>"}.
    The current SSM document receives Datadog's InstanceId as IncidentId. The bridge
    uses that echoed value to find exactly one command for the configured instance,
    avoiding reliance on an unverified SendCommand output binding. The app role needs
    ssm:ListCommands and ssm:GetCommandInvocation; denied access is reported unknown.
    """
    expected = os.getenv("DATADOG_APP_NOTIFICATION_TOKEN", "").strip()
    if not expected:
        return JSONResponse(status_code=503, content={"status": "unavailable", "reason": "verifier_not_configured"})
    supplied = request.headers.get("authorization", "")
    if not supplied.lower().startswith("bearer ") or not secrets.compare_digest(supplied[7:].strip(), expected):
        return JSONResponse(status_code=401, content={"status": "unauthorized"})

    try:
        raw = await request.body()
        if len(raw) > 4096:
            return JSONResponse(status_code=413, content={"status": "invalid_request"})
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        return JSONResponse(status_code=400, content={"status": "invalid_request"})
    if not isinstance(payload, dict):
        return JSONResponse(status_code=400, content={"status": "invalid_request"})

    from service.w3_recovery_verification import (
        classify_live_health,
        classify_ssm_invocation,
        find_unique_command,
        validate_instance_id,
        validate_workflow_run_id,
    )

    expected_instance = os.getenv("SMIOT_RECOVERY_INSTANCE_ID", "").strip()
    workflow_run_id = payload.get("workflow_run_id")
    instance_id = payload.get("instance_id")
    if not validate_workflow_run_id(workflow_run_id) or not validate_instance_id(instance_id, expected_instance):
        return JSONResponse(status_code=400, content={"status": "invalid_request", "reason": "workflow_run_or_instance_not_allowed"})
    workflow_run_id = workflow_run_id.strip()
    instance_id = instance_id.strip()

    def _get_invocation():
        import boto3
        from botocore.config import Config
        region = os.getenv("AWS_REGION", "ap-southeast-2").strip() or "ap-southeast-2"
        client = boto3.client(
            "ssm",
            region_name=region,
            config=Config(
                connect_timeout=2,
                read_timeout=3,
                retries={"total_max_attempts": 1, "mode": "standard"},
            ),
        )
        paginator = client.get_paginator("list_commands")
        commands = []
        for page in paginator.paginate(
            InstanceId=instance_id,
            Filters=[{"key": "DocumentName", "value": "SMIOT-GuardedStartApp"}],
            PaginationConfig={"PageSize": 50, "MaxItems": 501},
        ):
            commands.extend(page.get("Commands", []))
        if len(commands) > 500:
            return {"_bridge_status": "not_verified", "reason": "ssm_command_search_limit_reached"}
        match = find_unique_command(commands, workflow_run_id, instance_id)
        if match["status"] != "matched":
            return {"_bridge_status": match["status"], "reason": match.get("reason")}
        return client.get_command_invocation(CommandId=match["command_id"], InstanceId=instance_id)

    try:
        invocation = await asyncio.wait_for(asyncio.to_thread(_get_invocation), timeout=5)
    except Exception as exc:
        # SSM command listings can lag shortly after SendCommand; AccessDenied
        # and transport errors are also unknown, never evidence of recovery.
        error_code = getattr(exc, "response", {}).get("Error", {}).get("Code")
        if error_code in {"InvocationDoesNotExist", "InvalidCommandId"}:
            return JSONResponse(status_code=202, content={"status": "pending", "verified": False, "phase": "ssm_result_not_visible_yet"})
        system_logger.warning("smiot_w3_verification status=unknown reason=ssm_read_unavailable")
        return JSONResponse(status_code=503, content={"status": "unknown", "reason": "ssm_read_unavailable"})

    if invocation.get("_bridge_status") == "pending":
        return JSONResponse(status_code=202, content={"status": "pending", "verified": False, "phase": "ssm_command_not_visible_yet"})
    if invocation.get("_bridge_status") == "not_verified":
        return JSONResponse(
            status_code=422,
            content={
                "status": "not_verified",
                "verified": False,
                "reason": invocation.get("reason", "ssm_command_not_unique"),
            },
        )
    result = classify_ssm_invocation(invocation, expected_run_id=workflow_run_id)
    if result["status"] == "pending":
        return JSONResponse(status_code=202, content={"status": "pending", "verified": False, "phase": "ssm_command_running"})
    if result["status"] == "not_verified":
        system_logger.warning("smiot_w3_verification status=not_verified reason=%s", result.get("reason", "unknown"))
        return JSONResponse(
            status_code=422,
            content={
                "status": "not_verified",
                "verified": False,
                "reason": result.get("reason", "guard_did_not_verify"),
                "ssm_status": result.get("ssm_status"),
            },
        )

    mongo_ok, newest = await _read_mongo_health()
    live_health = build_healthz_payload(
        mongo_ok=mongo_ok,
        mqtt_ok=_mqtt_connected(),
        newest_sample_at=newest,
        now=datetime.now(timezone.utc),
    )
    if not classify_live_health(live_health):
        return JSONResponse(
            status_code=202,
            content={"status": "pending", "verified": False, "phase": "waiting_for_live_health_and_fresh_telemetry", "health": live_health},
        )
    outcome = "recovered" if result["status"] == "recovery_action_verified" else "already_healthy"
    system_logger.info("smiot_w3_verification status=%s run_id=%s", outcome, result.get("run_id", "unknown"))
    return {
        "status": outcome,
        "verified": True,
        "ssm_status": "Success",
        "guard_run_id": result.get("run_id"),
        "guard_timestamp": result.get("guard_timestamp"),
        "health": live_health,
    }


@app.post('/api/internal/safe-mode/recovery-clear')
async def verify_recovery_and_clear_safe_mode(request: Request):
    """Datadog recovery workflow entrypoint; app verifier owns all recovery checks."""
    expected = os.getenv("SAFE_MODE_RECOVERY_TOKEN", "").strip()
    if not expected:
        return JSONResponse(status_code=503, content={"result": "disabled", "reason": "recovery endpoint is not configured"})
    supplied = request.headers.get("authorization", "")
    if not supplied.lower().startswith("bearer ") or not secrets.compare_digest(supplied[7:].strip(), expected):
        return JSONResponse(status_code=401, content={"result": "unauthorized"})
    if not _recovery_clear_lock.acquire(blocking=False):
        return JSONResponse(status_code=409, content={"result": "already_running"})
    try:
        verifier = Path(__file__).parent / "scripts" / "verify_and_clear_demo_safe_mode.py"
        try:
            result = await asyncio.to_thread(
                subprocess.run,
                [sys.executable, "-X", "utf8", str(verifier)],
                cwd=str(Path(__file__).parent),
                capture_output=True,
                text=True,
                timeout=55,
                check=False,
            )
        except subprocess.TimeoutExpired:
            system_logger.error("smiot_recovery_verification result=timeout source=datadog_workflow")
            return JSONResponse(status_code=504, content={"result": "timeout"})
        output = result.stdout.strip().splitlines()
        details = {}
        if output:
            try:
                details = json.loads(output[-1])
            except json.JSONDecodeError:
                details = {"result": "invalid_verifier_output"}
        if result.returncode != 0:
            reason = (result.stderr or result.stdout or "recovery verifier rejected CLEAR")[-1000:].strip()
            # Policy guard rejections are expected when this action runs on Alert
            # or before recovery is proven. Infrastructure/verifier errors remain
            # non-2xx so Datadog marks the action failed and responders can see it.
            guarded = "Refusing to clear HOLD:" in reason
            system_logger.warning("smiot_recovery_verification result=%s source=datadog_workflow reason=%s", "not_cleared" if guarded else "verifier_error", reason)
            return JSONResponse(
                status_code=200 if guarded else 503,
                content={"result": "verification_not_passed" if guarded else "verifier_error", "details": details, "reason": reason},
            )
        system_logger.info("smiot_recovery_verification source=datadog_workflow details=%s", json.dumps(details, separators=(",", ":")))
        return {"source": "application_recovery_verifier", **details}
    finally:
        _recovery_clear_lock.release()


@app.post('/api/integrations/datadog/notification')
async def receive_datadog_notification(request: Request):
    """Persist an authenticated Datadog workflow event in the app notification bell.

    Configure DATADOG_APP_NOTIFICATION_TOKEN on the app and store the matching
    value in a Datadog HTTP Connection; never place it in workflow JSON.
    """
    expected = os.getenv("DATADOG_APP_NOTIFICATION_TOKEN", "").strip()
    if not expected:
        return JSONResponse(status_code=503, content={"result": "disabled"})
    supplied = request.headers.get("authorization", "")
    if not supplied.lower().startswith("bearer ") or not secrets.compare_digest(
        supplied[7:].strip(), expected
    ):
        return JSONResponse(status_code=401, content={"result": "unauthorized"})

    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > 8192:
                return JSONResponse(status_code=413, content={"result": "payload_too_large"})
        except ValueError:
            return JSONResponse(status_code=400, content={"result": "invalid_content_length"})
    try:
        raw_body = await request.body()
        if len(raw_body) > 8192:
            return JSONResponse(status_code=413, content={"result": "payload_too_large"})
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception:
        return JSONResponse(status_code=400, content={"result": "invalid_json"})
    from service.datadog_notifications import NotificationValidationError, normalize_datadog_notification
    try:
        payload = normalize_datadog_notification(payload)
    except NotificationValidationError as exc:
        return JSONResponse(status_code=exc.status_code, content={"result": exc.result})

    event_id = payload["event_id"]
    message = payload["message"]
    farm_key = payload["farm_key"] or ""
    if farm_key:
        from service.farm_registry import FARM_KEYS
        if farm_key not in FARM_KEYS:
            return JSONResponse(status_code=422, content={"result": "unknown_farm"})
    category = payload["category"]
    severity = payload["severity"]

    # Treat a supplied incident ID as a candidate link until MongoDB confirms
    # the incident exists and belongs to the supplied farm. Never let a
    # workflow close/recover an incident through this notification endpoint.
    linked_incident = None
    correlation_status = "unlinked"
    requested_incident_id = payload["incident_id"]
    if requested_incident_id:
        try:
            linked_incident = collection("operational_incidents").find_one(
                {"_id": requested_incident_id},
                {"_id": 1, "farm_key": 1, "status": 1},
            )
        except Exception as exc:
            system_logger.warning("datadog_notification_incident_lookup_failed error=%s", type(exc).__name__)
            linked_incident = None
        if linked_incident:
            incident_farm = str(linked_incident.get("farm_key") or "")
            if incident_farm and (not farm_key or incident_farm == farm_key):
                correlation_status = "verified"
                farm_key = farm_key or incident_farm
            else:
                linked_incident = None

    now = datetime.now(timezone.utc)
    # Event IDs are caller supplied; hash them so arbitrary characters never
    # enter Mongo _id values and repeated workflow deliveries stay idempotent.
    import hashlib
    dedupe_id = "datadog:" + hashlib.sha256(event_id.encode("utf-8")).hexdigest()
    document = {
        "_id": dedupe_id,
        "id": dedupe_id,
        "source": "datadog_workflow",
        "event_id": event_id,
        "message": message,
        "text": message,
        "category": category,
        "severity": severity,
        "farm_key": farm_key or None,
        "incident_id": str(linked_incident["_id"]) if linked_incident else None,
        "correlation_status": correlation_status,
        "workflow_status": payload["status"],
        "decision_code": payload["decision_code"],
        "action_code": payload["action_code"],
        "verification_status": payload["verification_status"],
        "monitor_id": payload["monitor_id"],
        "workflow_run_id": payload["workflow_run_id"] or event_id,
        "evidence_refs": payload["evidence_refs"],
        "workflow_name": payload["workflow_name"],
        "workflow_id": payload["workflow_id"],
        "created_at": now,
        "time": now.astimezone().strftime("%H:%M:%S"),
        "read": False,
    }
    try:
        result = collection("notifications").update_one(
            {"_id": dedupe_id}, {"$setOnInsert": document}, upsert=True
        )
    except Exception as exc:
        system_logger.exception("datadog_app_notification_persist_failed")
        return JSONResponse(status_code=503, content={"result": "storage_unavailable", "error": type(exc).__name__})

    inserted = result.upserted_id is not None
    if linked_incident:
        # Persist workflow evidence on the matched incident, but do not modify
        # its lifecycle status. The app recovery verifier remains the sole
        # authority allowed to mark an incident recovered.
        workflow_run_id = payload["workflow_run_id"] or event_id
        observation = {
            "event_id": event_id,
            "workflow_id": payload["workflow_id"],
            "workflow_run_id": workflow_run_id,
            "monitor_id": payload["monitor_id"],
            "status": payload["status"] or "unknown",
            "decision_code": payload["decision_code"],
            "action_code": payload["action_code"],
            "verification_status": payload["verification_status"] or "unknown",
            "evidence_refs": payload["evidence_refs"],
            "observed_at": now,
        }
        incident_set = {"updated_at": now, "last_workflow_observation": observation}
        if payload["workflow_id"]:
            incident_set["workflow_id"] = payload["workflow_id"]
        if payload["monitor_id"]:
            incident_set["monitor_id"] = payload["monitor_id"]
        try:
            incident_update = {
                "$set": incident_set,
                "$addToSet": {
                    "evidence.workflow_execution_ids": workflow_run_id,
                    "evidence.workflow_observations": observation,
                },
            }
            if payload["monitor_id"]:
                incident_update["$addToSet"]["evidence.monitor_ids"] = payload["monitor_id"]
            if payload["evidence_refs"]:
                incident_update["$addToSet"]["evidence.workflow_refs"] = {"$each": payload["evidence_refs"]}
            collection("operational_incidents").update_one(
                {"_id": str(linked_incident["_id"]), "farm_key": farm_key}, incident_update
            )
        except Exception as exc:
            system_logger.exception("datadog_workflow_incident_evidence_persist_failed")
            return JSONResponse(status_code=503, content={"result": "incident_evidence_unavailable", "error": type(exc).__name__})
    if inserted:
        from pages.home import state
        state.setdefault("notifications", []).insert(0, {
            "time": document["time"], "text": message,
            "incident_id": document["incident_id"],
            "event_id": document["event_id"],
            "farm_key": document["farm_key"],
            "severity": document["severity"],
            "workflow_name": document["workflow_name"],
            "workflow_id": document["workflow_id"],
            "workflow_run_id": document["workflow_run_id"],
            "workflow_status": document["workflow_status"],
            "monitor_id": document["monitor_id"],
            "decision_code": document["decision_code"],
            "action_code": document["action_code"],
            "verification_status": document["verification_status"],
            "correlation_status": document["correlation_status"],
        })
        state["notifications"] = state["notifications"][:20]
        state["_update_counter"] = state.get("_update_counter", 0) + 1
    return JSONResponse(
        status_code=202 if inserted else 200,
        content={"result": "received" if inserted else "duplicate", "stored": True, "app_bell_updated": inserted},
    )

# Chỉ dùng cho dev/local để session không mất mỗi lần restart. Không phải bí mật thật.
DEV_STORAGE_SECRET = "smiot-dev-only-storage-secret"


def _seconds_from_env(name, default):
    try:
        return max(1.0, float(os.getenv(name, str(default))))
    except ValueError:
        return float(default)


if __name__ in {"__main__", "__mp_main__"}:
    is_production = os.getenv("APP_ENV", "development").strip().lower() == "production"
    storage_secret = os.getenv("NICEGUI_STORAGE_SECRET", "").strip()
    if not storage_secret:
        if is_production:
            storage_secret = secrets.token_urlsafe(48)
            system_logger.warning(
                "NICEGUI_STORAGE_SECRET chua duoc cau hinh trong production: dang dung secret ngau nhien, "
                "session dang nhap se mat khi app restart. Hay dat NICEGUI_STORAGE_SECRET."
            )
        else:
            storage_secret = DEV_STORAGE_SECRET
    ui.run(
        title='SMIOT System',
        port=8080,
        favicon='📊',
        reload=False,
        storage_secret=storage_secret,
        reconnect_timeout=_seconds_from_env("SMIOT_RECONNECT_TIMEOUT", 90),
    )
