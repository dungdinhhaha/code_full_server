"""Project overview based on configured farms and recent persisted telemetry."""

from nicegui import ui, app
from pages.home import CUSTOM_CSS, sidebar, global_topbar
from pages.login import check_login
from service.auth import get_user_farms
from service.mongodb_store import collection
from datetime import datetime, timedelta, timezone

# Keep the farm cards in sync with the canonical registry used by auth and telemetry.
from service.farm_registry import FARMS as FARM_REGISTRY
_GRADIENTS = (
    "linear-gradient(135deg,#d1fae5,#a7f3d0)",
    "linear-gradient(135deg,#fef3c7,#fde68a)",
    "linear-gradient(135deg,#dbeafe,#93c5fd)",
    "linear-gradient(135deg,#f1f5f9,#e2e8f0)",
)
PROJECTS = {
    farm_key: {"name": label, "emoji": emoji, "gradient": _GRADIENTS[index % len(_GRADIENTS)]}
    for index, (farm_key, label, emoji) in enumerate(FARM_REGISTRY)
}

def _load_recent_farm_signals(farm_keys: list[str], now: datetime) -> dict[str, dict] | None:
    """One MongoDB aggregation for configured farms; seeded history is excluded."""
    cutoff = now - timedelta(minutes=10)
    pipeline = [
        {"$match": {"meta.measurement_type": "node", "meta.farm_key": {"$in": farm_keys},
                     "timestamp": {"$gte": cutoff}, "source.demo_seed_version": {"$exists": False}}},
        {"$group": {"_id": "$meta.farm_key", "last_sample_at": {"$max": "$timestamp"},
                    "sample_count_10m": {"$sum": 1}, "nodes": {"$addToSet": "$meta.node_id"}}},
    ]
    try:
        return {row["_id"]: row for row in collection("telemetry").aggregate(pipeline, maxTimeMS=2500)}
    except Exception:
        return None


def _signal_state(row: dict | None, now: datetime) -> tuple[str, str, str]:
    if not row or not row.get("last_sample_at"):
        return "NO DATA", "Chưa nhận mẫu live trong 10 phút", "offline"
    stamp = row["last_sample_at"]
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    age_s = max(0, (now - stamp.astimezone(timezone.utc)).total_seconds())
    if age_s <= 90:
        return "LIVE", f"Mẫu mới {int(age_s)} giây trước", "active"
    if age_s <= 300:
        return "STALE", f"Mẫu cuối {int(age_s)} giây trước", "warning"
    return "NO DATA", f"Mẫu cuối {int(age_s // 60)} phút trước", "offline"

# ─────────────────────────────────────────────
# PROJECT PAGE CSS
# ─────────────────────────────────────────────
PROJECT_CSS = """
.stat-card {
    text-align: center;
    padding: 24px 18px;
    background: white;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    transition: all 0.2s;
}
.stat-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}

.proj-card {
    background: white; border-radius: 12px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 1px 2px rgba(0,0,0,0.02);
    padding: 0; overflow: hidden; cursor: pointer;
    transition: all 0.2s;
}
.proj-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.05);
}
.proj-card .proj-thumb {
    height: 100px; display: flex; align-items: center; justify-content: center;
    font-size: 42px; position: relative; overflow: hidden;
}

.badge-active { background: #dcfce7; color: #16a34a; }
.badge-warning { background: #fef3c7; color: #d97706; }
.badge-offline { background: #f1f5f9; color: #94a3b8; }
.badge-admin { background: #fae8ff; color: #9333ea; }
.badge-operator { background: #dbeafe; color: #2563eb; }
.badge-viewer { background: #f1f5f9; color: #6b7280; }

.timeline-item {
    display: flex; gap: 12px; padding: 12px 0;
    border-bottom: 1px solid #f0f0f0;
}
.timeline-item:last-child { border-bottom: none; }
.timeline-dot {
    width: 32px; height: 32px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 14px; flex-shrink: 0;
}
@media (max-width:1024px){
    .pj-kpi{ grid-template-columns:repeat(2,minmax(0,1fr)) !important; }
    .pj-cards{ grid-template-columns:repeat(2,minmax(0,1fr)) !important; }
    .pj-split{ grid-template-columns:1fr !important; }
}
@media (max-width:480px){
    .pj-kpi, .pj-cards{ grid-template-columns:1fr !important; }
    .card:has(> .pj-users){ overflow-x:auto; }
    .pj-users{ min-width:520px; }
}
"""


# ─────────────────────────────────────────────
# PAGE
# ─────────────────────────────────────────────
@ui.page('/projects')
def trang_projects():
    if not check_login(): return

    ui.add_head_html(f"<style>{CUSTOM_CSS}{PROJECT_CSS}</style>")
    sidebar(active="Projects")

    # Đọc danh sách user và farm từ MongoDB.
    from service import auth
    users_data = []
    now = datetime.now(timezone.utc)
    try:
        for user in auth.get_all_users():
            username, role, la_str = user.get("username"), user.get("role"), user.get("last_active")
            is_online = False
            last_active_display = "Chưa rõ"
            if la_str:
                try:
                    la_dt = datetime.strptime(str(la_str), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
                    is_online = (now - la_dt).total_seconds() < 120
                    last_active_display = la_dt.strftime("%H:%M:%S %d/%m/%Y")
                except (TypeError, ValueError):
                    pass
            farm_names = [PROJECTS[fk]["name"] for fk in auth.get_user_farms(user["id"]) if fk in PROJECTS]
            bg_color = "#4361ee" if role == "admin" else "#10b981" if role == "operator" else "#6b7280"
            users_data.append({"name": username, "farms": ", ".join(farm_names) if farm_names else ("Toàn quyền" if role == "admin" else "Chưa gán"), "role": role, "bg": bg_color, "is_online": is_online, "last_active": last_active_display})
    except Exception as e:
        print(f"❌ [LỖI TRANG PROJECT] {e}")

    # Lấy thông tin farm cho user hiện tại
    current_user_id = app.storage.user.get('user_id')
    current_role = app.storage.user.get('role', 'viewer')
    if current_role == 'admin':
        visible_farm_keys = list(PROJECTS.keys())
    elif current_user_id:
        visible_farm_keys = get_user_farms(current_user_id)
        if not visible_farm_keys: visible_farm_keys = ["greenhouse_a"]
    else:
        visible_farm_keys = ["greenhouse_a"]

    visible_projects = [{"key": k, **PROJECTS[k]} for k in visible_farm_keys if k in PROJECTS]
    farm_signals = _load_recent_farm_signals([p["key"] for p in visible_projects], now)
    for project in visible_projects:
        project["signal"] = farm_signals.get(project["key"]) if farm_signals is not None else None
        if farm_signals is None:
            project["signal_text"], project["signal_detail"], project["status"] = "UNKNOWN", "Không đọc được MongoDB", "unknown"
        else:
            project["signal_text"], project["signal_detail"], project["status"] = _signal_state(project["signal"], now)

    # Tính stats
    total_farms = len(visible_projects)
    live_count = sum(1 for p in visible_projects if p["status"] == "LIVE")
    stale_count = sum(1 for p in visible_projects if p["status"] == "STALE")
    unknown_count = sum(1 for p in visible_projects if p["status"] == "unknown")
    recent_samples = sum(int((p["signal"] or {}).get("sample_count_10m", 0)) for p in visible_projects)
    
    STATS = [
        {"icon": "🏡", "value": str(total_farms), "label": "Nhà màng được cấu hình", "bg": "linear-gradient(135deg,#dbeafe,#eff6ff)"},
        {"icon": "📡", "value": str(live_count), "label": "Đang nhận mẫu mới", "bg": "linear-gradient(135deg,#dcfce7,#f0fdf4)"},
        {"icon": "⏳", "value": str(stale_count), "label": "Mẫu đang cũ", "bg": "linear-gradient(135deg,#fef3c7,#fffbeb)"},
        {"icon": "📈", "value": str(recent_samples), "label": "Mẫu live · 10 phút", "bg": "linear-gradient(135deg,#e0e7ff,#eef2ff)"},
        {"icon": "❔", "value": str(unknown_count), "label": "Chưa đọc được trạng thái", "bg": "linear-gradient(135deg,#fae8ff,#fdf4ff)"},
    ]

    with ui.element("div").classes("main-content"):
        global_topbar("Quản Lý Dự Án", "📂")

        with ui.element("div").classes("content-area"):
            with ui.element("div").style("display:flex;flex-direction:column;gap:20px;width:100%"):

                # ── Stats Row (5 columns) ──
                with ui.element("div").style("width:100%"):
                    ui.label("📊  TỔNG QUAN HỆ THỐNG").classes("section-header").style("color:#4361ee;margin-bottom:12px")
                    with ui.element("div").classes("pj-kpi").style("display:grid;grid-template-columns:repeat(5,1fr);gap:16px;"):
                        for s in STATS:
                            with ui.element("div").classes("stat-card"):
                                with ui.element("div").style("display:flex;align-items:center;gap:14px;justify-content:center;"):
                                    with ui.element("div").style(f"background:{s['bg']};width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;"):
                                        ui.label(s["icon"]).style("font-size:20px")
                                    with ui.element("div").style("text-align:left;"):
                                        ui.label(s["value"]).style("font-size:26px;font-weight:800;color:#1a1a2e;line-height:1;")
                                        ui.label(s["label"]).style("font-size:11px;color:#94a3b8;font-weight:600;letter-spacing:.06em;text-transform:uppercase;margin-top:4px;")

                # ── Projects Grid ──
                with ui.element("div").style("width:100%"):
                    ui.label("🏡  TÍN HIỆU THEO NHÀ MÀNG").classes("section-header").style("color:#10b981;margin-bottom:4px")
                    ui.label("Chỉ tính mẫu live trong 10 phút gần nhất; lịch sử seed không làm nhà màng hiện Online.").classes("text-xs text-slate-500 mb-3")
                    num_cols = min(len(visible_projects), 4)
                    badge_by_state = {"LIVE": "active", "STALE": "warning", "NO DATA": "offline", "UNKNOWN": "offline"}
                    with ui.element("div").classes("pj-cards").style(f"display:grid;grid-template-columns:repeat({num_cols},1fr);gap:16px;"):
                        for p in visible_projects:
                            with ui.element("div").classes("proj-card"):
                                with ui.element("div").classes("proj-thumb").style(f"background:{p['gradient']};"):
                                    ui.label(p["emoji"]).style("font-size:42px")
                                with ui.element("div").style("padding:16px 18px;"):
                                    with ui.element("div").style("display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"):
                                        ui.label(p["name"]).style("font-weight:700;font-size:15px;color:#1a1a2e;")
                                        badge_class = f"badge badge-{badge_by_state[p['signal_text']]}"
                                        with ui.element("span").classes(badge_class).style("display:inline-flex;align-items:center;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;text-transform:uppercase"):
                                            ui.label(p["signal_text"])
                                    status_bg = {"LIVE": "#dcfce7", "STALE": "#fef3c7", "NO DATA": "#f1f5f9", "UNKNOWN": "#fee2e2"}[p["signal_text"]]
                                    status_color = {"LIVE": "#16a34a", "STALE": "#d97706", "NO DATA": "#64748b", "UNKNOWN": "#b91c1c"}[p["signal_text"]]
                                    with ui.element("div").style(f"background:{status_bg};padding:9px 12px;border-radius:8px;display:flex;align-items:center;gap:6px;margin:10px 0"):
                                        ui.label("●").style(f"font-size:11px;color:{status_color}")
                                        ui.label(p["signal_detail"]).style(f"font-size:12px;color:{status_color};font-weight:600")
                                    sample_count = int((p["signal"] or {}).get("sample_count_10m", 0))
                                    nodes = [n for n in (p["signal"] or {}).get("nodes", []) if n is not None]
                                    with ui.element("div").style("display:flex;gap:12px;font-size:12px;color:#64748b;background:#f8fafc;padding:8px 10px;border-radius:8px;"):
                                        ui.label(f"📨 {sample_count} mẫu / 10 phút")
                                        ui.label(f"📡 {len(nodes)} node có dữ liệu")

                    if farm_signals is None:
                        ui.label("Không truy vấn được MongoDB; trạng thái nhà màng chưa xác định.").classes("text-sm text-red-700 mt-2")
                    if visible_projects:
                        ui.echart({
                            "tooltip": {"trigger": "axis"},
                            "grid": {"left": 45, "right": 20, "top": 20, "bottom": 32},
                            "xAxis": {"type": "category", "data": [p["name"] for p in visible_projects]},
                            "yAxis": {"type": "value", "name": "Mẫu / 10 phút", "minInterval": 1},
                            "series": [{"type": "bar", "barMaxWidth": 54,
                                        "data": [int((p["signal"] or {}).get("sample_count_10m", 0)) if farm_signals is not None else None for p in visible_projects],
                                        "itemStyle": {"color": "#3b82f6", "borderRadius": [6, 6, 0, 0]}}],
                        }).classes("w-full h-64 rounded-xl bg-white p-3 mt-4")

                # ── Bottom: Activity + Permission Summary ──
                with ui.element("div").style("width:100%"):
                    ui.label("👥  QUYỀN TRUY CẬP").classes("section-header").style("color:#7c3aed;margin-bottom:12px")
                    with ui.element("div").classes("pj-split").style("display:grid;grid-template-columns:1fr;gap:16px;"):
                        # Permission Summary (5 cột)
                        with ui.element("div").classes("card").style("padding:18px;"):
                            ui.label("👥  USER ONLINE STATUS").classes("section-header").style("color:#7c3aed;font-size:13px;margin-bottom:12px;")
                            with ui.element("div").classes("pj-users").style("display:grid;grid-template-columns:1fr 1.2fr 0.7fr 0.5fr 1fr;gap:10px;padding:8px 0;border-bottom:1px solid #f0f0f0;font-size:11px;color:#94a3b8;font-weight:600;text-transform:uppercase"):
                                ui.label("User")
                                ui.label("Farm Access")
                                ui.label("Role")
                                ui.label("Status")
                                ui.label("Last Active")
                            for pu in users_data:
                                with ui.element("div").classes("pj-users").style("display:grid;grid-template-columns:1fr 1.2fr 0.7fr 0.5fr 1fr;gap:10px;padding:10px 0;border-bottom:1px solid #f8f8f8;align-items:center"):
                                    with ui.element("div").style("display:flex;align-items:center;gap:8px;overflow:hidden"):
                                        initials = pu["name"].split()
                                        init_str = "+".join(initials)
                                        ui.image(f"https://ui-avatars.com/api/?name={init_str}&background={pu['bg'].replace('#','')}&color=fff&size=28").style("width:28px;height:28px;border-radius:50%")
                                        ui.label(pu["name"]).style("font-weight:600;font-size:13px;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;")
                                    ui.label(pu["farms"]).style("color:#64748b;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;")
                                    badge_cls = f"badge badge-{pu['role']}"
                                    ui.label(pu["role"].capitalize()).classes(badge_cls).style("display:inline-flex;align-items:center;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:700;text-transform:uppercase")
                                    
                                    # Status Dot pulsing
                                    dot_class = "dot-green" if pu["is_online"] else "dot-red"
                                    with ui.element("div").style("display:flex;justify-content:center"):
                                        ui.element("div").classes(dot_class).style("width:8px;height:8px;border-radius:50%")
                                    ui.label(pu["last_active"]).style("font-size:11px;color:#94a3b8")
