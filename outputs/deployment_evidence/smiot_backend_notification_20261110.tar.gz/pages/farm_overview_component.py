"""MongoDB-backed fleet signal matrix for the SMIOT Home page."""

from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Callable

from nicegui import app, ui

from service import auth
from service.agronomic_thresholds import classify_advisory, soil_moisture_calibration_note
from service.farm_registry import FARMS, FARM_KEYS
from service.mongodb_store import database
from service.telemetry_health import compute_node_status

_CACHE: dict[tuple[str, ...], tuple[float, list[dict], list[dict], str | None]] = {}
_CACHE_LOCK = threading.Lock()
_CACHE_SECONDS = 5
_ACTIVE_INCIDENTS = ["open", "holding", "recovering", "acked", "investigating"]


def _allowed_farms() -> list[str]:
    role = app.storage.user.get("role", "viewer")
    user_id = app.storage.user.get("user_id")
    if role == "admin":
        return list(FARM_KEYS)
    if user_id is None:
        return []
    try:
        permitted = set(auth.get_user_farms(int(user_id)))
    except Exception:
        return []
    return [farm for farm in FARM_KEYS if farm in permitted]


def _aggregate_farms(farm_keys: list[str]) -> list[dict]:
    """Fetch latest real Mongo sample per farm/signal/device plus related events."""
    db = database()
    by_farm = {farm: {"farm_key": farm, "samples": [], "incidents": [], "notices": []}
               for farm in farm_keys}
    # Query one farm/measurement pair at a time so the compound index on
    # (meta.farm_key, meta.measurement_type, timestamp) can serve each latest-
    # sample scan. A collection-wide sort/group over the full time-series was
    # timing out on the live database as history grew.
    measurements = ("node", "flow", "water", "drain_sensor", "ventilation_feedback", "plc", "inverter")
    for farm in farm_keys:
        latest_by_source: dict[tuple[str, str, str], dict] = {}
        for measurement in measurements:
            cursor = db.telemetry.find(
                {
                    "meta.farm_key": farm,
                    "meta.measurement_type": measurement,
                    "source.demo_seed_key": {"$exists": False},
                    "source.demo_seed_version": {"$nin": ["smiot-demo-history-v1", "smiot-demo-history-v2"]},
                },
                {"timestamp": 1, "meta": 1, "readings": 1, "source": 1, "_id": 0},
            ).sort("timestamp", -1).limit(80)
            for sample in cursor:
                meta, source = sample.get("meta") or {}, sample.get("source") or {}
                node = meta.get("node_id", source.get("node_id"))
                device = source.get("device_id", meta.get("source_table", ""))
                key = (measurement, str(node or ""), str(device or ""))
                # Cursor is newest-first, so the first record for each device
                # is the most recently persisted real sample.
                latest_by_source.setdefault(key, sample)
        by_farm[farm]["samples"].extend(latest_by_source.values())

    incidents = db.operational_incidents.find(
        {"farm_key": {"$in": farm_keys}, "status": {"$in": _ACTIVE_INCIDENTS}},
        {"_id": 0, "farm_key": 1, "incident_id": 1, "kind": 1, "status": 1, "opened_at": 1, "lot_id": 1, "node_id": 1},
    ).sort("opened_at", -1).limit(len(farm_keys) * 8)
    for incident in incidents:
        farm = incident.get("farm_key")
        if farm in by_farm and len(by_farm[farm]["incidents"]) < 8:
            by_farm[farm]["incidents"].append(incident)

    notices = db.notifications.find(
        {"farm_key": {"$in": farm_keys}, "source": {"$ne": "demo_seed"}},
        {"_id": 0, "farm_key": 1, "message": 1, "category": 1, "severity": 1, "created_at": 1, "node_id": 1, "advisory_id": 1},
    ).sort("created_at", -1).limit(len(farm_keys) * 30)
    per_farm_notices = {farm: 0 for farm in farm_keys}
    for notice in notices:
        farm = notice.get("farm_key")
        if farm in by_farm and per_farm_notices[farm] < 30:
            by_farm[farm]["notices"].append(notice)
            per_farm_notices[farm] += 1
    return list(by_farm.values())


def _aggregate_unscoped_notices() -> list[dict]:
    """Fetch system-level notices without associating them with a farm."""
    db = database()
    notices = db.notifications.find(
        {"farm_key": {"$in": [None, ""]}, "source": {"$ne": "demo_seed"}},
        {"_id": 0, "farm_key": 1, "message": 1, "category": 1, "severity": 1, "created_at": 1, "node_id": 1, "advisory_id": 1},
    ).sort("created_at", -1).limit(30)
    result = []
    for notice in notices:
        # Missing and empty farm keys remain explicitly unscoped in the view.
        notice["farm_key"] = None
        result.append(notice)
    return result

def _load(farm_keys: list[str]) -> tuple[list[dict], list[dict], str | None]:
    if not farm_keys:
        return [], [], None
    key = tuple(farm_keys)
    now = datetime.now(timezone.utc).timestamp()
    with _CACHE_LOCK:
        cached = _CACHE.get(key)
        if cached and now - cached[0] < _CACHE_SECONDS:
            return cached[1], cached[2], cached[3]
        try:
            by_farm = {row["farm_key"]: row for row in _aggregate_farms(farm_keys)}
            rows = [by_farm.get(farm, {"farm_key": farm, "samples": [], "incidents": [], "notices": []}) for farm in farm_keys]
            error = None
        except Exception as exc:
            rows = [{"farm_key": farm, "samples": [], "incidents": [], "notices": []} for farm in farm_keys]
            error = f"Không đọc được dữ liệu MongoDB ({type(exc).__name__})."
        try:
            unscoped_notices = _aggregate_unscoped_notices()
        except Exception:
            unscoped_notices = []
        _CACHE[key] = (now, rows, unscoped_notices, error)
        return rows, unscoped_notices, error


def _sample_index(row: dict) -> dict[tuple[str, int | None], list[dict]]:
    out: dict[tuple[str, int | None], list[dict]] = {}
    for sample in row.get("samples", []):
        meta, source = sample.get("meta") or {}, sample.get("source") or {}
        kind = str(meta.get("measurement_type") or "")
        node = meta.get("node_id", source.get("node_id"))
        try:
            node = int(node) if node is not None else None
        except (TypeError, ValueError):
            node = None
        out.setdefault((kind, node), []).append(sample)
    return out


def _latest_with(index: dict, kind: str, field: str, node: int | None = None) -> dict | None:
    samples = [sample for sample in index.get((kind, node), [])
               if isinstance((sample.get("readings") or {}).get(field), (int, float))
               and not isinstance((sample.get("readings") or {}).get(field), bool)]
    return max(samples, key=lambda sample: sample.get("timestamp") or datetime.min.replace(tzinfo=timezone.utc), default=None)


def _node_state(index: dict, node_id: int, now: datetime) -> dict:
    sample = max(index.get(("node", node_id), []), key=lambda x: x.get("timestamp") or datetime.min.replace(tzinfo=timezone.utc), default=None)
    provenance = (sample or {}).get("source") or {}
    status = compute_node_status((sample or {}).get("timestamp"), now,
                                 last_sequence=provenance.get("sequence"), boot_id=provenance.get("boot_id")) if sample else {"status": "UNKNOWN", "age_s": None}
    return {"sample": sample, "status": status}


def _channel_freshness(sample: dict | None, expected_interval_s: float) -> dict:
    stamp = (sample or {}).get("timestamp")
    if not isinstance(stamp, datetime):
        return {"status": "UNKNOWN", "age_s": None}
    if stamp.tzinfo is None:
        stamp = stamp.replace(tzinfo=timezone.utc)
    age_s = max(0.0, (datetime.now(timezone.utc) - stamp).total_seconds())
    fresh_s = max(45.0, expected_interval_s * 1.5)
    stale_s = max(fresh_s, expected_interval_s * 3.0)
    state = "ONLINE" if age_s <= fresh_s else "STALE" if age_s <= stale_s else "OFFLINE"
    return {"status": state, "age_s": round(age_s, 1)}


def _prepared(rows: list[dict]) -> list[dict]:
    now = datetime.now(timezone.utc)
    prepared = []
    for row in rows:
        index = _sample_index(row)
        nodes = [_node_state(index, n, now) for n in (1, 2)]
        channels = {}
        for kind, field, interval in (("water", "ph_val", 300), ("flow", "flow_f1", 60),
                                      ("drain_sensor", "drain_l", 300),
                                      ("ventilation_feedback", "state", 15)):
            sample = _latest_with(index, kind, field)
            channels[kind] = {"sample": sample, "status": _channel_freshness(sample, interval)}
        incidents = row.get("incidents") or []
        states = [node["status"].get("status") for node in nodes]
        states.extend(channel["status"].get("status") for channel in channels.values())
        agronomy_flag = False
        for node in nodes:
            readings = (node.get("sample") or {}).get("readings") or {}
            agronomy_flag |= any(
                classify_advisory(metric, readings.get(field))["state"] == "advisory"
                for metric, field in (("air_temp_c", "air_temp"), ("air_humidity_pct", "air_hum"))
            )
        if incidents or agronomy_flag or any(state in {"OFFLINE", "STALE"} for state in states):
            overall = "Cần xem"
        elif all(state == "ONLINE" for state in states):
            overall = "Ổn định"
        else:
            overall = "Chưa đủ dữ liệu"
        prepared.append({"farm_key": row["farm_key"], "index": index, "nodes": nodes, "channels": channels,
                         "incidents": incidents, "notices": row.get("notices", []),
                         "agronomy_flag": agronomy_flag, "overall": overall})
    return prepared


def _numeric(sample: dict | None, key: str) -> float | None:
    if not sample:
        return None
    value = (sample.get("readings") or {}).get(key)
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def _fmt(value: float | None, unit: str = "", digits: int = 1) -> str:
    return "—" if value is None else f"{value:.{digits}f}{unit}"


def _freshness_color(status: dict, sample: dict | None) -> str:
    if sample is None:
        return "missing"
    return {"ONLINE": "observed", "STALE": "advisory", "OFFLINE": "problem"}.get(status.get("status"), "missing")


def _render_signal_matrix(cards: list[dict], labels: dict[str, str], on_select: Callable[[str], None]) -> None:
    ordered = list(reversed(cards))
    columns = ["Tình trạng", "Kết nối", "Nhiệt độ", "Ẩm không khí", "Ẩm đất", "EC đất", "pH nước", "Lưu lượng", "Thoát nước", "Quạt"]
    rows = [labels.get(card["farm_key"], card["farm_key"]) for card in ordered]
    cells = []
    for y, card in enumerate(ordered):
        index = card["index"]
        status = card["overall"]
        status_state = "problem" if status == "Cần xem" else "normal" if status == "Ổn định" else "missing"
        entries = [("● " + status, status_state, "Tình trạng được suy ra từ hai mẫu node mới nhất và sự cố MongoDB đang mở")]
        node_states = [node["status"].get("status", "UNKNOWN") for node in card["nodes"]]
        node_text = "N1 " + {"ONLINE":"Mới","STALE":"Cũ","OFFLINE":"Mất","UNKNOWN":"—"}.get(node_states[0], "—") + " · N2 " + {"ONLINE":"Mới","STALE":"Cũ","OFFLINE":"Mất","UNKNOWN":"—"}.get(node_states[1], "—")
        entries.append((node_text, "problem" if any(s == "OFFLINE" for s in node_states) else "advisory" if any(s == "STALE" for s in node_states) else "normal" if all(s == "ONLINE" for s in node_states) else "missing", "Trạng thái theo thời gian nhận mẫu MongoDB; ngưỡng ONLINE/STALE/OFFLINE hiện có của app"))

        node_samples = [node.get("sample") if node["status"].get("status") == "ONLINE" else None
                        for node in card["nodes"]]
        temps, rhs, soil, ecs = [], [], [], []
        for sample in node_samples:
            readings = (sample or {}).get("readings") or {}
            for key, target in (("air_temp", temps), ("air_hum", rhs), ("soil_hum", soil), ("ec", ecs)):
                value = readings.get(key)
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    target.append(float(value))
        temp = round(sum(temps) / len(temps), 1) if temps else None
        rh = round(sum(rhs) / len(rhs), 1) if rhs else None
        soil_mean = round(sum(soil) / len(soil), 1) if soil else None
        ec = round(sum(ecs) / len(ecs), 2) if ecs else None
        temp_advice = classify_advisory("air_temp_c", temp)
        rh_advice = classify_advisory("air_humidity_pct", rh)
        entries.extend([
            (_fmt(temp, "°C"), "advisory" if temp_advice["state"] == "advisory" else "normal" if temp is not None else "missing", temp_advice.get("message") or "Trung bình các node có mẫu mới"),
            (_fmt(rh, "%"), "advisory" if rh_advice["state"] == "advisory" else "normal" if rh is not None else "missing", rh_advice.get("message") or "Trung bình các node có mẫu mới"),
            (_fmt(soil_mean, "%"), "observed" if soil_mean is not None else "missing", soil_moisture_calibration_note()),
            (_fmt(ec, "", 2), "observed" if ec is not None else "missing", "EC đất trung bình từ node có mẫu mới · mS/cm"),
        ])
        ph_sample = card["channels"]["water"]["sample"]
        ph_value = _numeric(ph_sample, "ph_val")
        flow_sample = card["channels"]["flow"]["sample"]
        flow_readings = (flow_sample or {}).get("readings") or {}
        flow = sum(float(flow_readings.get(k) or 0) for k in ("flow_f1", "flow_f2"))
        drain_sample = card["channels"]["drain_sensor"]["sample"]
        drain_readings = (drain_sample or {}).get("readings") or {}
        vent_sample = card["channels"]["ventilation_feedback"]["sample"]
        vent_readings = (vent_sample or {}).get("readings") or {}
        ph_state = _freshness_color(card["channels"]["water"]["status"], ph_sample) if ph_value is not None else "missing"
        entries.extend([
            (_fmt(ph_value, "", 2), ph_state, "pH từ mẫu water mới nhất có giá trị"),
            (_fmt(flow, " L/ph", 1) if flow_sample else "—", _freshness_color(card["channels"]["flow"]["status"], flow_sample), "Tổng flow_f1 + flow_f2; 0 là số đo hợp lệ khi bơm đang dừng"),
            (_fmt(_numeric(drain_sample, "drain_l"), " L", 2), _freshness_color(card["channels"]["drain_sensor"]["status"], drain_sample), "Lượng nước thoát ghi nhận"),
            (f"{int(vent_readings.get('state', 0))} · {int(vent_readings.get('fan_rpm', 0))} rpm" if vent_sample else "—",
             _freshness_color(card["channels"]["ventilation_feedback"]["status"], vent_sample), "Phản hồi trạng thái và tốc độ quạt"),
        ])
        fill = {"missing":"#f1f3f2", "observed":"#edf2f6", "normal":"#edf7f0", "advisory":"#fff0df", "problem":"#fde9e7"}
        numeric_state = {"missing":0, "observed":1, "normal":2, "advisory":3, "problem":4}
        for x, (value, state, tooltip) in enumerate(entries):
            cells.append({"name": f"{value} · {tooltip}", "value": [x, y, numeric_state[state]],
                          "itemStyle": {"color": fill[state], "borderColor":"#ffffff", "borderWidth":3},
                          "label": {"show": True, "formatter": value, "fontSize": 10, "color":"#45564d" if state in {"normal","missing"} else "#9b3e2e"},
                          "tooltip": tooltip})
    option = {
        "animation": False,
        "grid": {"left": 112, "right": 14, "top": 38, "bottom": 12},
        "tooltip": {"position": "top", "formatter": "{b}"},
        "xAxis": {"type": "category", "data": columns, "splitArea": {"show": True}, "axisLabel": {"interval": 0, "rotate": 0, "fontSize": 9, "color":"#64746b"}, "axisTick":{"show":False}, "axisLine":{"show":False}},
        "yAxis": {"type": "category", "data": rows, "inverse": True, "splitArea":{"show":True}, "axisLabel":{"fontSize":10,"color":"#34483d"}, "axisTick":{"show":False}, "axisLine":{"show":False}},
        "visualMap": {"show": False, "min": 0, "max": 4, "inRange": {"color": ["#f1f3f2", "#edf2f6", "#edf7f0", "#fff0df", "#fde9e7"]}},
        "series": [{"type":"heatmap", "data":cells, "label":{"show":True}, "emphasis":{"itemStyle":{"shadowBlur":8,"shadowColor":"rgba(0,0,0,.18)"}}}],
    }
    with ui.element("div").style("background:#fff;border:1px solid #e5ebe6;border-radius:14px;padding:12px 14px 4px;overflow-x:auto"):
        with ui.row().classes("w-full items-center justify-between no-wrap"):
            ui.label("Bản đồ tín hiệu 10 farm").style("font-size:15px;font-weight:800;color:#233c30")
            ui.label("Bấm một hàng để mở farm · màu cam/đỏ cần chú ý").style("font-size:10px;color:#87948d")
        chart = ui.echart(option).classes("w-full").style("height:390px;min-width:920px")

        def open_farm(event) -> None:
            args = getattr(event, "args", {}) or {}
            value = args.get("value") if isinstance(args, dict) else None
            try:
                farm_label = rows[int(value[1])]
            except (TypeError, ValueError, IndexError):
                return
            on_select(farm_label)

        chart.on("click", open_farm)
        with ui.row().classes("items-center gap-4 flex-wrap").style("padding:2px 2px 10px"):
            for color, text in (("#27815b", "Trong dải tham khảo"), ("#d18428", "Cảnh báo tham khảo"), ("#c3483e", "Sự cố/node lỗi"), ("#728699", "Có số đo · chưa đặt ngưỡng"), ("#9aa39e", "Chưa có mẫu")):
                with ui.row().classes("items-center no-wrap").style("gap:5px"):
                    ui.element("span").style(f"width:9px;height:9px;border-radius:2px;background:{color}")
                    ui.label(text).style("font-size:10px;color:#6d7c73")


def _incident_label(kind: str | None) -> str:
    return {
        "soil_humidity_flatline": "Cảm biến đất đứng số", "false_offline": "Báo offline sai",
        "service_down": "Ứng dụng ngừng hoạt động", "water_overrun": "Lưu lượng vượt giới hạn",
        "pipe_leak": "Nghi rò đường ống", "vent_stuck": "Quạt không phản hồi",
        "soil_spike": "Độ ẩm đất tăng bất thường", "soil_out_of_range": "Số đo đất ngoài khoảng",
    }.get(str(kind), "Sự cố đang mở")


def _notice_feed_entries(cards: list[dict], labels: dict[str, str], unscoped_notices: list[dict]) -> list[tuple[str, dict | None, dict]]:
    """Combine farm-scoped and system-level notices without cross-linking them."""
    notices_by_id = {}
    for card in cards:
        for notice in card.get("notices", []):
            identity = (card["farm_key"], notice.get("advisory_id"), notice.get("message"), notice.get("created_at"))
            if not notice.get("message", "").startswith("SMIOT demo:"):
                notices_by_id[identity] = (labels.get(card["farm_key"], card["farm_key"]), card, notice)
    for notice in unscoped_notices:
        identity = (None, notice.get("advisory_id"), notice.get("message"), notice.get("created_at"))
        if not notice.get("message", "").startswith("SMIOT demo:"):
            notices_by_id[identity] = ("Toàn hệ thống", None, notice)
    return list(notices_by_id.values())


def _render_event_feed(cards: list[dict], labels: dict[str, str], on_select: Callable[[str], None],
                       unscoped_notices: list[dict] | None = None) -> None:
    incidents = [(card, incident) for card in cards for incident in card.get("incidents", [])]
    notices = _notice_feed_entries(cards, labels, unscoped_notices or [])
    with ui.column().classes("w-full").style("gap:9px;margin-top:14px"):
        with ui.row().classes("w-full items-center justify-between"):
            ui.label("Thông báo & sự cố").classes("farm-section-title")
            ui.label(f"{len(incidents)} sự cố đang mở · {len(notices)} thông báo").classes("farm-chart-note")
        if not incidents and not notices:
            with ui.element("div").style("background:#fff;border:1px solid #e5ebe6;border-radius:12px;padding:15px;color:#66756c;font-size:12px"):
                ui.label("Chưa có sự cố hoặc thông báo mới từ MongoDB.")
        for card, incident in incidents[:10]:
            farm_label = labels.get(card["farm_key"], card["farm_key"])
            with ui.row().classes("w-full items-center justify-between no-wrap").style("background:#fff7f4;border:1px solid #f2ddd7;border-left:4px solid #c3483e;border-radius:10px;padding:9px 12px"):
                with ui.column().style("gap:2px;min-width:0"):
                    ui.label(f"{farm_label} · {_incident_label(incident.get('kind'))}").style("font-size:12px;font-weight:750;color:#87382f")
                    ui.label(f"{incident.get('incident_id','')} · {incident.get('status','')}").style("font-size:10px;color:#8c736d")
                ui.button("Mở farm", on_click=lambda label=farm_label: on_select(label)).props("flat dense no-caps").style("color:#9b3e2e")
        for scope_label, card, notice in notices[:8]:
            with ui.row().classes("w-full items-center justify-between no-wrap").style("background:#fff;border:1px solid #e5ebe6;border-radius:10px;padding:9px 12px"):
                with ui.column().style("gap:2px;min-width:0"):
                    ui.label(f"{scope_label} · {notice.get('message','')}").style("font-size:12px;color:#43544a")
                    ui.label(str(notice.get("created_at") or "")).style("font-size:10px;color:#8a968f")
                if card is not None:
                    farm_key = card["farm_key"]
                    farm_label = labels.get(farm_key, farm_key)
                    ui.button("Mở farm", on_click=lambda label=farm_label: on_select(label)).props("flat dense no-caps").style("color:#347455")


def render_farm_overview(on_select: Callable[[str], None]) -> None:
    farm_keys = _allowed_farms()
    rows, unscoped_notices, error = _load(farm_keys)
    cards = _prepared(rows)
    labels = {key: label for key, label, _emoji in FARMS}
    counts = {"Ổn định": 0, "Cần xem": 0, "Chưa đủ dữ liệu": 0}
    for card in cards:
        counts[card["overall"]] += 1
    now_text = datetime.now().astimezone().strftime("%H:%M · %d/%m")
    with ui.element("section").classes("farm-control-room"):
        with ui.element("header").classes("farm-control-hero"):
            with ui.column().style("gap:5px"):
                ui.label("Trung tâm điều hành").classes("farm-control-title")
                ui.label("Một màn hình để biết farm nào ổn, farm nào cần kiểm tra.").classes("farm-control-subtitle")
            with ui.column().classes("items-end").style("gap:3px"):
                ui.label(f"{len(farm_keys)} farm").classes("farm-control-count")
                ui.label(f"MongoDB · {now_text}").classes("farm-control-updated")
        with ui.element("div").classes("farm-kpi-strip"):
            _kpi("Đang theo dõi", len(farm_keys), "nhà màng", "#286e50")
            _kpi("Ổn định", counts["Ổn định"], "node có mẫu mới", "#25805a")
            _kpi("Cần xem", counts["Cần xem"], "có sự cố hoặc dữ liệu cũ", "#c27a22")
            _kpi("Chưa đủ dữ liệu", counts["Chưa đủ dữ liệu"], "chưa kết luận", "#7d8983")
            _kpi("Sự cố đang mở", sum(len(c["incidents"]) for c in cards), "lấy từ MongoDB", "#b4493f")
        if error:
            ui.label(error).classes("farm-overview-error")
        elif not farm_keys:
            ui.label("Tài khoản chưa được cấp quyền xem farm nào.").classes("farm-overview-error")
        else:
            _render_signal_matrix(cards, labels, on_select)
            ui.label("Ngưỡng nhiệt độ/độ ẩm là cảnh báo tham khảo; độ ẩm đất chưa tô ngưỡng vì chưa hiệu chuẩn cảm biến. Không tự điều khiển bơm.").classes("farm-chart-note")
            _render_event_feed(cards, labels, on_select, unscoped_notices)


def _kpi(label: str, value: int, detail: str, color: str) -> None:
    with ui.element("div").classes("farm-kpi"):
        ui.label(label).classes("farm-kpi-label")
        with ui.row().classes("items-baseline no-wrap").style("gap:6px"):
            ui.label(str(value)).style(f"font-size:25px;line-height:1;font-weight:800;color:{color}")
            ui.label(detail).classes("farm-kpi-detail")
